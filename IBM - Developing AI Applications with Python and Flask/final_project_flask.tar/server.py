from flask import Flask, render_template, request, jsonify
from EmotionDetection.emotion_detection import emotion_detector

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/emotionDetector', methods=['POST'])
def detect_emotion():
    try:
        text_to_analyze = request.form['textToAnalyze']
        result = emotion_detector(text_to_analyze)

        if result and result['dominant_emotion'] is not None:
            emotions = result.copy()
            dominant_emotion = emotions.pop('dominant_emotion', None)

            response_text = (
                "For the given statement, the system response is "
                + ", ".join(f"'{key}': {value}" for key, value in emotions.items())
                + f". The dominant emotion is {dominant_emotion}."
            )

            return jsonify({'system_response': response_text})
        else:
            return jsonify({'system_response': "Invalid text! Please try again."})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)